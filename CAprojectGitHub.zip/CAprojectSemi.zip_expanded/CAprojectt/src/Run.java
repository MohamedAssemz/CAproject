import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Run {
	DataMemory DM = new DataMemory();
	public InstructionMemory IM = new InstructionMemory();
	public Registers R = new Registers();
	ArrayList<String> items;
    int cycles = 0;
    byte a1;
    byte b1;
    byte imm1;
    byte rx1;
    byte rx2;
    byte op1;
    short inst;
    public Run() {
    }

    
	public static int toDic(String arg1){
        return Integer.parseInt(arg1,2);
    }
    public static String toBin(int arg1,int x){
        String arg = Integer.toBinaryString(arg1);
        while (arg.length()<x){
            arg = "0"+arg;
        }
        return arg;
    }
    public void fetch() {
        
    		inst = IM.inst[IM.pc];
    		IM.pc++;

    	}
    
    
    public static byte getvalue(short a,int f,int l){
        
        short msk = 0;
        for(int j= f;j<=l;j++){
            msk = (short) ((1<<j)|msk);
        }
        byte r = (byte) ((a & msk)>>>f);
        return r;
        
    }
public void Decode(short inst1) {
	
	byte opc = getvalue(inst1,12,15);  // bits31:28
    byte ri1 = getvalue(inst1,6,11);      // bits27:24
    byte ri2 = getvalue(inst1,0,5); // bit23:20
    byte imm2 = getvalue(inst1,0,5);
    //////get data from data memory using 

     a1 = R.getReg(ri1);
     b1 = R.getReg(ri2);
     imm1 = (byte)imm2;
     rx1 = (byte)ri1;
     rx2 = (byte)ri2;
     op1 = (byte) opc;

    
    System.out.println("R"+ri1+" Address "+" = "+ri1);
    System.out.println("opcode = "+op1);
    System.out.println("immediate = "+imm1);
    System.out.println("PC = "+IM.pc);

   
} 


public void Execute(byte op, byte a, byte b, byte imm, byte rx) {
	byte output =0b0;
	byte msb = (byte) (imm>>5);
	byte comp = (byte) 0b11000000;
    if(msb == 0b1) {
    	imm = (byte) (imm|comp);
    }
    short msk = 0b00000001;
  
	switch (op) {
	//add 0000
	case 0b0000:{
    short x = (short) (a+b);
	output = (byte) (a+b);
	byte outputf = (byte) (a+b);
	
	
	short tempc1 = (short) (x>>8);
	short tempc3 = (short) (tempc1&msk);
	if (tempc3 == 1) {
		R.SR.setC('1');	
	}else R.SR.setC('0');
	
	
	short tempv1 = (short) ((a>>5)&msk);
	short tempv2 = (short) ((b>>5)&msk);
	if(tempv1 == tempv2 ){
		short tempv3 = (short) (a+b);
		short tempv4 = (short) ((tempv3>>5)&msk);
		if( tempv1 != tempv4) {
		R.SR.setV('1');
		}
	}else R.SR.setV('0');

	byte tempn1 = (byte) ((output>>6)&msk);
	if(tempn1 == 1) {
		R.SR.setN('1');
	}else R.SR.setN('0');
	
	char temps1 = R.SR.getN();
	char temps2 = R.SR.getV();
	int temps3;
	int temps4;
	char temps6;
	if (temps1 == '0') {temps3 = 0;} else {temps3 = 1;}
	if (temps2 == '0') {temps4 = 0;} else {temps4 = 1;}
	int temps5 = temps3^temps4;
	if (temps5 == 0) {temps6 = '0';} else {temps6 = '1';}
	R.SR.setS(temps6);
	
	if(output == 0) {
		R.SR.setZ('1');
	}else R.SR.setZ('0');
 
	R.setReg(rx, outputf);
	
	System.out.println("R"+rx+" = "+R.getReg(rx));
	System.out.println("R"+rx2+" = "+R.getReg(rx2));
	
	   break;
	   }
/////////////////////////////////////////////////////////////
	//sub	0001
		case 0b0001:{ output = (byte) (a-b);
		byte outputf = (byte) (a-b);
		
		short tempv1 = (short) ((a>>5)&msk);
		short tempv2 = (short) ((b>>5)&msk);
		if(tempv1 == tempv2 ){
			short tempv3 = (short) (a+b);
			short tempv4 = (short) ((tempv3>>5)&msk);
			if( tempv1 != tempv4) {
			R.SR.setV('1');
			}
		}else R.SR.setV('0');


		byte tempn1 = (byte) ((output>>6)&msk);
		if(tempn1 == 1) {
			R.SR.setN('1');
		}else R.SR.setN('0');
			
			char temps1 = R.SR.getN();
			char temps2 = R.SR.getV();
			int temps3;
			int temps4;
			char temps6;
			if (temps1 == '0') {temps3 = 0;} else {temps3 = 1;}
			if (temps2 == '0') {temps4 = 0;} else {temps4 = 1;}
			int temps5 = temps3^temps4;
			if (temps5 == 0) {temps6 = '0';} else {temps6 = '1';}
			R.SR.setS(temps6);
			
			if(output == 0) {
				R.SR.setZ('1');
			}else R.SR.setZ('0');
			
			a = outputf; 
			R.setReg(rx,a);
			
			
			System.out.println("R"+rx+" = "+R.getReg(rx));
			System.out.println("R"+rx2+" = "+R.getReg(rx2));
			
			
			break;
		}
/////////////////////////////////////////////////////////////
		//MUL 0010
		case 0b0010:
		 {output = (byte) (a*b) ; 
		 byte outputf = (byte) (a*b);
		
		 byte tempn1 = (byte) ((output>>6)&msk);
			if(tempn1 == 1) {
				R.SR.setN('1');
			}else R.SR.setN('0');
		
		
		if(output == 0) {
			R.SR.setZ('1');
		}else R.SR.setZ('0');
		
		a = outputf; 
		R.setReg(rx,a);
		
		
		System.out.println("R"+rx+" = "+R.getReg(rx));
		System.out.println("R"+rx2+" = "+R.getReg(rx2));
		
		
		break;
		 }
/////////////////////////////////////////////////////////////
		 //LDI 0011
		case 0b0011:{ R.setReg(rx, imm); 
		
		
		System.out.println("R"+rx+" = "+R.getReg(rx));
		
		
		break; }
		/////////////////////////////////////////
		
		// BEQZ 0100
		case 0b0100:{ if(R.GR[rx]== 0) {
			for(int i=0;i<imm;i++) {
				fetch();
			}
			};
			System.out.println("New PC = "+IM.pc);
		 break;}
/////////////////////////////////////////////////////////////
		
		//// AND 0101
		
		case 0b0101: {output = (byte) (a&b) ;
		byte outputf = (byte) (a&b);
		
		byte tempn1 = (byte) ((output>>6)&msk);
		if(tempn1 == 1) {
			R.SR.setN('1');
		}else R.SR.setN('0');
		
		
		if(output == 0) {
			R.SR.setZ('1');
		}else R.SR.setZ('0');
		
		a = outputf; 
		R.setReg(rx,a);
		
		
		System.out.println("R"+rx+" = "+R.getReg(rx));
		System.out.println("R"+rx2+" = "+R.getReg(rx2));
		
		
		break;
		}
/////////////////////////////////////////////////////////////	
		//OR 
		case 0b0110:{ output = (byte) (a|b) ;
		byte outputf = (byte) (a|b);
	    
		byte tempn1 = (byte) ((output>>6)&msk);
		if(tempn1 == 1) {
			R.SR.setN('1');
		}else R.SR.setN('0');
		
		
		if(output == 0) {
			R.SR.setZ('1');
		}else R.SR.setZ('0');
		
		a = outputf; 
		R.setReg(rx,a);
		
		
		System.out.println("R"+rx+" = "+R.getReg(rx));
		System.out.println("R"+rx2+" = "+R.getReg(rx2));
		
		
		break;
		}
		//AND
       case 0b0111:{
    	   for(int i=0;i<(((a<<6)|b)-IM.pc);i++) {
				fetch();
			} 
					
			System.out.println("New PC = "+IM.pc);
			
			
			
			break;
		}
/////////////////////////////////////////////////////////////	
       
       //SLC
       case (byte) 0b11111000:{
    	   byte tempa0 = a;
   	    byte tempa1 = a;
   		byte temp1 = (byte) (tempa0<<imm);
   	    byte temp2 = (byte) ( tempa1>>>(8-imm));
   	    output = (byte) (temp1 | temp2);
   	    byte outputf = (byte) (output);
   	    
   	 byte tempn1 = (byte) ((output>>6)&msk);
 	if(tempn1 == 1) {
 		R.SR.setN('1');
 	}else R.SR.setN('0');
   		
   		
   		if(output == 0) {
   			R.SR.setZ('1');
   		}else R.SR.setZ('0');
   		
   		 a = outputf; 
   		 R.setReg(rx,a);
   		
   		
   		System.out.println("R"+rx+" = "+R.getReg(rx));
   		
   		break;
       }
       
       
       
       
		//SRC
		case (byte) 0b11111001:{
			
			byte tempa0 = a;
		    byte tempa1 = a;
			byte temp1 = (byte) (tempa0<<(8-imm));
		    byte temp2 = (byte) ( tempa1>>>imm);
		    output = (byte) (temp2 | temp1);
		    byte outputf = (byte) (output);
		    
		    
		    
		    byte tempn1 = (byte) ((output>>6)&msk);
			if(tempn1 == 1) {
				R.SR.setN('1');
			}else R.SR.setN('0');
			
			
			if(output == 0) {
				R.SR.setZ('1');
			}else R.SR.setZ('0');
			
			a = outputf; 
			R.setReg(rx,a);
			
			
			System.out.println("R"+rx+" = "+R.getReg(rx));
			
			
			
			
			
			
			break;
		}
/////////////////////////////////////////////////////////////		
		//LB
		case (byte) 0b11111010: { 
			byte tempo = (byte) DM.getData(imm);
			R.setReg(rx, tempo); 
			
			
			System.out.println("R"+rx+" = "+R.getReg(rx));
			
		break;
		}
/////////////////////////////////////////////////////////////	
		//SB
		case (byte) 0b11111011: {DM.setData(imm,R.getReg(rx)); 
		
		System.out.println("R"+rx+" = "+R.getReg(rx));
		System.out.println("MEM["+imm+"] = "+DM.getData(rx));
		
		break;
		}
		
			
		}
	

	
	}
	
	public void parse(String fileName) throws IOException {
		try {
			File file = new File("C:\\Users\\moham\\OneDrive\\Desktop\\" + fileName + ".txt");
			BufferedReader br = new BufferedReader(new FileReader(file));
			String data;
			items = new ArrayList<String>();
			while ((data = br.readLine()) != null) {
				if (!data.equals("")) {
					items.add(data);
				}
			}
		
			br.close(); 
			System.out.println("Number of Instructions = ");
			System.out.println(items.size());
			System.out.println("----------");
	
			short opcode;
			short totalInst = 0b0000000000000000;
			//String[] line = new String[100];
			for (int i = 0; i < items.size(); i++) {
				
				String[] line = (items.get(i).split(" "));
				
				if (line[0].equals("ADD")) {
					opcode = 0b0000000000000000;
					 
					short r1 = Short.parseShort(line[1].substring(1));
					short r2 = Short.parseShort(line[2].substring(1));
					r1 = (short) (r1 << 6);
					totalInst = (short) (opcode | r1 | r2);
				}
				if (line[0].equals("SUB")) {
					opcode = 0b0001000000000000;
					 
					short r1 = Short.parseShort(line[1].substring(1));
					short r2 = Short.parseShort(line[2].substring(1));
					r1 = (short) (r1 << 6);
					totalInst = (short) (opcode | r1 | r2);
				}
				if (line[0].equals("MUL")) {
					opcode = 0b0010000000000000;
					 
					short r1 = Short.parseShort(line[1].substring(1));
					short r2 = Short.parseShort(line[2].substring(1));
					r1 = (short) (r1 << 6);
					totalInst = (short) (opcode | r1 | r2);
				}
				if (line[0].equals("LDI")) {
					opcode = 0b0011000000000000;
					 
					short r1 = Short.parseShort(line[1].substring(1));
					short imm = (short) (Short.parseShort(line[2]) & 0b0000000000111111);
					r1 = (short) (r1 << 6);
					totalInst = (short) (opcode | r1 | imm);

				}
				if (line[0].equals("BEQZ")) {
					opcode = 0b0100000000000000;
					 
					short r1 = Short.parseShort(line[1].substring(1));
					short imm = (short) (Short.parseShort(line[2]) & 0b0000000000111111);
					r1 = (short) (r1 << 6);
					totalInst = (short) (opcode | r1 | imm);
				}
				if (line[0].equals("AND")) {
					opcode = 0b0101000000000000;
					 
					short r1 = Short.parseShort(line[1].substring(1));
					short r2 = Short.parseShort(line[2].substring(1));
					r1 = (short) (r1 << 6);
					totalInst = (short) (opcode | r1 | r2);
				}
				//7
				if (line[0].equals("OR")) {
					opcode = 0b0110000000000000;
					 
					short r1 = Short.parseShort(line[1].substring(1));
					short r2 = Short.parseShort(line[2].substring(1));
					r1 = (short) (r1 << 6);
					totalInst = (short) (opcode | r1 | r2);
				}
				//8
				if (line[0].equals("JR")) {
					opcode = (short) 0b0111000000000000;
					 
					short r1 = Short.parseShort(line[1].substring(1));
					short r2 = Short.parseShort(line[2].substring(1));
					r1 = (short) (r1 << 6);
					totalInst = (short) (opcode | r1 | r2);
				}
				//9
				if (line[0].equals("SLC")) {
					opcode = (short)0b1000000000000000;
					 
					short r1 = Short.parseShort(line[1].substring(1));
					short imm = (short) (Short.parseShort(line[2])& 0b0000000000111111);
					r1 = (short) (r1 << 6);
					totalInst = (short) (opcode | r1 | imm);
				}
				//10
				if (line[0].equals("SRC")) {
					opcode = (short)0b1001000000000000;
					 
					short r1 = Short.parseShort(line[1].substring(1));
					short imm = (short) (Short.parseShort(line[2]) & 0b0000000000111111);
					r1 = (short) (r1 << 6);
					totalInst = (short) (opcode | r1 | imm);
				}
				//11
				if (line[0].equals("LB")) {
					opcode = (short)0b1010000000000000;
					 
					short r1 = Short.parseShort(line[1].substring(1));
					short imm = (short) (Short.parseShort(line[2]) & 0b0000000000111111);
					r1 = (short) (r1 << 6);
					totalInst = (short) (opcode | r1 | imm);
				}
				//12
				if (line[0].equals("SB")) {
					
					opcode = (short)0b1011000000000000;
					 
					short r1 = Short.parseShort(line[1].substring(1));
					short imm = (short) (Short.parseShort(line[2]) & 0b0000000000111111);
					r1 = (short) (r1 << 6);
					totalInst = (short) (opcode | r1 | imm);
				}
				System.out.println("Instruction "+(i+1)+" : ");
				System.out.println(items.get(i));
				System.out.println(Integer.toBinaryString(totalInst));
				System.out.println("----------");
				IM.setInstruction(totalInst);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		IM.pc = 0;

	}

	

	public void clock() {
		cycles++;
	}

	public void Run1() {
		
		for(int i = 0; i<items.size(); i++) {
			for(int j = 0;j<=items.size()+2;j++) {
				clock();
				if(cycles==1) {
					if(IM.pc <= items.size()) {
					System.out.println("At Cycle = "+cycles);
					System.out.println("Instruction "+(IM.pc+1)+" is Fetching");
					System.out.println("-----------------------------------------");
				    fetch();
					 }
				 }if(cycles==2) {
					 if(IM.pc <= items.size()) {
					 System.out.println("At Cycle = "+cycles);
					 System.out.println("Instruction "+(IM.pc)+" is Decoding");
					 System.out.println("Instruction "+(IM.pc+1)+" is Fetching");
					 System.out.println("----------");
					 System.out.println("Decoding of Instruction "+IM.pc+" : ");
					 Decode(inst);
					 fetch();
					 System.out.println("-----------------------------------------");
					 }
				 }if(cycles>2 && cycles<=items.size()) {
					 if(IM.pc <= items.size()) {
					 System.out.println("At Cycle = "+cycles);
					 System.out.println("Instruction "+(IM.pc-1)+" is Excuting");
					 System.out.println("Instruction "+(IM.pc)+" is Decoding");
					 System.out.println("Instruction "+(IM.pc+1)+" is Fetching");
					 System.out.println("----------");
					 System.out.println("Excution of Instruction "+(IM.pc-1)+" : ");
					 Execute(op1,a1,b1,imm1,rx1);
					 R.printSREG();
					 System.out.println("----------");
					 System.out.println("Decoding of Instruction "+IM.pc+" : ");
		             Decode(inst);
					 fetch();
					 System.out.println("-----------------------------------------");
					 }
				 }if(cycles==items.size()+1) {
					 if(IM.pc <= items.size()) {
					 System.out.println("At Cycle = "+cycles);
					 System.out.println("Instruction "+(IM.pc-1)+" is Excuting");
					 System.out.println("Instruction "+(IM.pc)+" is Decoding");
					 System.out.println("----------");
					 System.out.println("Excution of Instruction "+(IM.pc-1)+" : ");
					 Execute(op1,a1,b1,imm1,rx1);
					 R.printSREG();
					 System.out.println("----------");
					 System.out.println("Decoding of Instruction "+IM.pc+" : ");
					 Decode(inst); 
					 System.out.println("-----------------------------------------");
					 }
				 }if(cycles==items.size()+2) {
					 if(IM.pc <= items.size()+1) {
					 System.out.println("At Cycle = "+cycles);
					 System.out.println("Instruction "+(IM.pc-1)+" is Excuting");
					 System.out.println("----------");
					 System.out.println("Excution of Instruction "+(IM.pc-1)+" : ");
			         Execute(op1,a1,b1,imm1,rx1);
			         R.printSREG();
			         System.out.println("-----------------------------------------");
					 }
				 }
		}
		}

	}

	public static void main(String[] args) {
		Run x = new Run();
		try {
			x.parse("test1");
			x.Run1();
			System.out.println("Final Registers:");
			for(int i = 0; i < x.R.GR.length; i++) {
				System.out.println(x.R.getReg((byte) i));
			}
			System.out.println("Data Memory:");
			for(byte i = 0; i < 64; i++) {
				System.out.println(x.DM.getData(i));
			}
			System.out.println("Instruction Memory:");
			for(short i = 0; i < x.IM.inst.length; i++) {
				System.out.println(x.IM.getInstruction(i));
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	public void PrintAll() {
		System.out.println("Clock cycle"+cycles);
		System.out.println("Instruction"+IM.getInstruction(IM.pc));
		System.out.println(""+cycles);
		System.out.println("Clock cycle"+cycles);
		System.out.println("Clock cycle"+cycles);
		
	}

	}

