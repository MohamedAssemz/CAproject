
public class DataMemory {
    public byte[] data;
    DataMemory(){
        data = new byte[2048];
        byte word = 0;
     
        for (int i = 0; i < data.length; i++) {
            data[i] = word;
        }
    }
    int getData(byte pos){
        return data[pos];
    }
    void setData(byte pos,byte value){
        data[pos] = value;
    }
    
}
