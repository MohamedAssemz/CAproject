public class InstructionMemory {
    public short [] inst;
    public short pc;
    InstructionMemory(){
    	
        inst = new short[1024];
        short zero = 0;
        pc =0;
        
        for(int i=0;i<inst.length;i++){
            inst[i] = zero;
        }
    }
    short getInstruction(short pc){
        return inst[pc];
    }
    void setInstruction(short value){
        inst[this.pc] = value;
        this.pc++;
    }
    public short getPC() {
    	return this.pc;
    }

    
}
