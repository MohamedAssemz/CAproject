
public class Registers {
    static byte Size = 8;
    public byte[] GR;
    public byte value;
    public byte address;
    SREG SR;
    class SREG{
        char[] value =("00000000").toCharArray();
        public void setC(char c) {
            value[3] = c;
        }

        public void setV(char v) {
            value[4] = v;
        }

        public void setN(char n) {
            value[5] = n;
        }

        public void setS(char s) {
            value[6] = s;
        }

        public void setZ(char z) {
            value[7] = z;
        }
        public char getC() {
            return value[3];
        }

        public char getV() {
            return value[4];
        }

        public char getN() {
            return value[5];
        }

        public char getS() {
            return value[6];
        }

        public char getZ() {
            return value[7];
        }
        
        			
        		}
    public void setReg(byte add,byte value) {
    	GR[add] = value;
        }
    
    public byte getReg(byte add) {
    	return GR[add];
    }
    public void printSREG() {
    	System.out.println(SR.value);
    	System.out.println("C: "+SR.getC());
    	System.out.println("V: "+SR.getV());
    	System.out.println("N: "+SR.getN());
    	System.out.println("S: "+SR.getS());
    	System.out.println("Z: "+SR.getZ());
    }
    
    
    
    Registers(){
        GR = new byte[64];
        for (int i=0;i<GR.length;i++) {
        	GR[i] = 00000000;
        	
        	
        }
        
        
        SR = new SREG();
    }
}